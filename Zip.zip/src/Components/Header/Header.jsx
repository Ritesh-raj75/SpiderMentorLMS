import { Link, Navigate, useNavigate } from "react-router-dom";
// import "./header.css";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import LanguageIcon from "@mui/icons-material/Language";
import SearchIcon from "@mui/icons-material/Search";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import Avatar from "@mui/material/Avatar";
import { deepPurple } from "@mui/material/colors";
import Badge from "@mui/material/Badge";
import { useEffect, useRef, useState } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { auth } from "../../Redux/login/action";
import { addToCart } from "../../Redux/cart/action";
import { colors } from "@mui/material";
export const Header = () => {
  const { cart } = useSelector((store) => store.cart);
  const { user } = useSelector((store) => store.auth);
  const { wishlist } = useSelector((store) => store.wishlist);
  const dispatch = useDispatch();

  useEffect(() => {
    let token =(localStorage.getItem("token")) || null;
    if (user.user == null) {
      if (token != null) {
        dispatch(auth(token));
      }
    }
    if (token != null)
      axios
        .get(`https://udemy-vr4p.onrender.com/cart/${token?.user?._id}`)
        .then(({ data }) => {
          console.log(data);
          dispatch(addToCart(data.length));
        });
  }, []);
  return (
    <>
      <header>
   <nav className="navbar navbar-expand-lg navbar-light sticky-top"  style={{padding:"5px 20px", color:"white", position:"fixed", top:0, width:"100%",  zIndex: 1030, backgroundColor: "rgb(44, 45, 45)", boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
  zIndex: 1030}}>
  <div className="container-fluid">
    <a className="navbar-brand fw-bold fs-4" style={{color:"orange",fontWeight:"bolder" }} href="/">SpiderMentor</a>

    <button className="navbar-toggler bg-light" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
      aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>

    <div className="collapse navbar-collapse" id="navbarSupportedContent">
      {/* Left Nav Links */}
      <ul className="navbar-nav mb-2 mb-lg-0 me-auto">
        <li className="nav-item">
          <a className="nav-link active text-light" aria-current="page" href="#">Courses</a>
        </li>
        <li className="nav-item">
          <a className="nav-link text-light" href="#">Notes</a>
        </li>
        <li className="nav-item dropdown">
          <a className="nav-link dropdown-toggle text-light"  href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Category
          </a>
          <ul className="dropdown-menu">
            <li><a className="dropdown-item" href="#">Action</a></li>
            <li><a className="dropdown-item" href="#">Another action</a></li>
            <li><hr className="dropdown-divider" /></li>
            <li><a className="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>
        <li className="nav-item">
           <a className="nav-link text-light" href="#">About</a>
         
        </li>
      </ul>

      {/* Centered Search */}
    <div className="mx-auto" style={{ width: "300px", position: "relative" }}>
            <input
              type="search"
              className="form-control"
              placeholder="Search courses, topics"
              aria-label="Search"
              style={{ paddingRight: "40px" }}
            />
            <button
              type="button"
              style={{
                position: "absolute",
                top: "50%",
                right: "10px",
                transform: "translateY(-50%)",
                background: "none",
                border: "none",
                cursor: "pointer",
              }}
            >
              <SearchIcon />
            </button>
          </div>

          {/* Right side icons/buttons */}
          <div className="d-flex align-items-center gap-2 ms-3">

            {user?.user && (
              <Link className="nav-link" to="#">
                <span className="nav-span">My Learning</span>
              </Link>
            )}

            {user?.user && (
              <Link to="/wishlist">
                <button className="btn btn-light">
                  <FavoriteBorderOutlinedIcon />
                </button>
              </Link>
            )}

            <Link to="/cart">
              <button className="btn btn-light">
                <Badge color="secondary" badgeContent={cart}>
                  <ShoppingCartOutlinedIcon />
                </Badge>
              </button>
            </Link>

            {user?.user && (
              <Link to="#">
                <button className="btn btn-light">
                  <Badge color="secondary" badgeContent={0}>
                    <NotificationsNoneOutlinedIcon />
                  </Badge>
                </button>
              </Link>
            )}

            {user?.user && (
              <Link to="#">
                <button className="btn btn-light">
                  <Badge color="secondary" overlap="circular" badgeContent=" " variant="dot">
                    <Avatar sx={{ bgcolor: deepPurple[500] }}>
                      {user.user.name[0].toUpperCase()}
                    </Avatar>
                  </Badge>
                </button>
              </Link>
            )}

            {!user?.user && (
              <>
                <Link to="/join/login-popup">
                  <button className="btn btn-outline-primary">Log in</button>
                </Link>
                <Link to="/join/signup-popup">
                  <button className="btn btn-primary">Sign up</button>
                </Link>
              </>
            )}
          </div>
        </div>
  </div>
</nav>




      </header>
    </>
  );
};
