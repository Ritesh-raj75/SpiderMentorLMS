import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { authFunction } from "../../Redux/login/action";
import { Navigate, Link } from "react-router-dom";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import { ColorButton } from "../ProdCard/popperprodcard";
// import "./login.css";

const Login = () => {
  const [userdata, setUser] = useState({ email: "", password: "" });
  const { user, loading, error } = useSelector((store) => store.auth);
  const dispatch = useDispatch();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...userdata, [name]: value });
  };

  if (user.token !== undefined) {
    return <Navigate to="/" />;
  }

  return (
    <div className="container d-flex align-items-center justify-content-center" style={{ minHeight: "110vh" }}>
      <div className="card shadow p-4" style={{ maxWidth: "400px", width: "100%" }}>
        <h4 className="text-center mb-3">Log In to SpiderMetor</h4>
        <hr />

        <div className="text-center mb-3">
          <img
            src="https://img-c.udemycdn.com/user/50x50/anonymous_3.png"
            alt="user"
            className="rounded-circle"
          />
          <p className="mt-2">Welcome back, {user?.user?.name}!</p>
        </div>

        {error && (
          <Alert severity="error" className="mb-3">
            <p className="mb-0">There was a problem logging in.</p>
            <p className="mb-0">Check your email and password or create an account.</p>
          </Alert>
        )}

        <div className="mb-3">
          <input
            type="email"
            name="email"
            className="form-control"
            placeholder="Email"
            onChange={handleChange}
          />
        </div>

        <div className="mb-3">
          <input
            type="password"
            name="password"
            className="form-control"
            placeholder="Password"
            onChange={handleChange}
          />
        </div>

        <div className="d-grid mx-auto pb-3">
  <ColorButton
    id="login_input"
    onClick={() => {
      const URL = "https://udemy-vr4p.onrender.com/join/login-popup";
      dispatch(authFunction(userdata, URL));
    }}
  >
    {loading ? (
      <CircularProgress size={24} style={{ color: "white" }} />
    ) : (
      "Log in"
    )}
  </ColorButton>
</div>


        <div className="text-center">
          <p className="mb-1">
            <Link to="#">Forgot Password?</Link>
          </p>
          
        </div>

        <hr />

        <div className="text-center">
          <p>
            Don't have an account? <Link to="/join/signup-popup">Sign up</Link>
          </p>
          <Link to="#" className="text-muted">Admin Login</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
