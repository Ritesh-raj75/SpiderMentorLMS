import "./signup.css";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import PersonIcon from "@mui/icons-material/Person";
import EmailIcon from "@mui/icons-material/Email";
import LockIcon from "@mui/icons-material/Lock";
import HelpIcon from "@mui/icons-material/Help";
import { Checkbox } from "@mui/material";
import React, { useState } from "react";
import { Header } from "../Header/Header";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import { ColorButton } from "../ProdCard/popperprodcard";
import { useDispatch, useSelector } from "react-redux";
import { authFunction } from "../../Redux/login/action";
import { Navigate } from "react-router-dom";

const Signup = () => {
  const [userdata, setUser] = useState({ name: "", email: "", password: "" });
  const { user, loading, error } = useSelector((store) => store.auth);
  const dispatch = useDispatch();
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...userdata, [name]: value });
  };
  if (user.token != undefined) {
    console.log(user._id);
    return <Navigate to={"/"} />;
  }
  return (
    <div className="container d-flex justify-content-center align-items-center " style={{ minHeight: "110vh" }}>
      <div className="card p-4 shadow-lg" style={{ maxWidth: "400px", width: "100%" }}>
        <h4 className="text-center mb-3">Sign up & Start Learning!</h4>
        <hr />

        {error && (
          <Alert className="mb-3" severity="error">
            <p className="mb-0">There was a problem creating your account.</p>
            <p className="mb-0">Check that your email address is spelled correctly.</p>
          </Alert>
        )}

        <div className="mb-3">
          <input
            onChange={handleChange}
            name="name"
            type="text"
            className="form-control"
            placeholder="Full Name"
          />
        </div>
        <div className="mb-3">
          <input
            onChange={handleChange}
            name="email"
            type="email"
            className="form-control"
            placeholder="Email"
          />
        </div>
        <div className="mb-3">
          <input
            onChange={handleChange}
            name="password"
            type="password"
            className="form-control"
            placeholder="Password"
          />
        </div>

        <div className="form-check mb-3">
          <input
            type="checkbox"
            className="form-check-input"
            id="signup_checkbox"
          />
          <label className="form-check-label" htmlFor="signup_checkbox">
            I'm in for emails with exciting discounts and personalized recommendations
          </label>
        </div>

        <div className="d-grid mx-auto">
          <ColorButton
            id="signup_input"
            onClick={() => {
              const URL = "https://udemy-vr4p.onrender.com/join/signup-popup";
              dispatch(authFunction(userdata, URL));
            }}
          >
            {loading ? <CircularProgress size={24} style={{ color: "white" }} /> : "Sign up"}
          </ColorButton>
        </div>

        <p className="mt-3 text-center small">
          By signing up you agree to our <a href="#">Terms of Use</a> and{" "}
          <a href="#">Privacy Policy</a>.
        </p>

        <hr />
        <div className="text-center">
          Already have an account? <a href="#">Log in</a>
        </div>
      </div>
    </div>
  );
};
export default Signup;
