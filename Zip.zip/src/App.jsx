// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";
import { AllRoutes } from "./Components/Routes/router";

export const App = () => {
  return (
    <div className="main-cont">
      <AllRoutes />
    </div>
  );
};
