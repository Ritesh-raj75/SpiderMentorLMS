import React, { useState } from "react";
import { db } from "../../firebaseConfig";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import emailjs from "emailjs-com";

export const Bottombar = () => {
  const [email, setEmail] = useState("");

  const handleSubscribe = async () => {
    if (!email || !email.includes("@")) {
      alert("❌ Please enter a valid email address.");
      return;
    }

    try {
      // 1. Save subscriber to Firestore
      await addDoc(collection(db, "newsletter_subscribers"), {
        email,
        timestamp: serverTimestamp(),
      });

      // 2. Send confirmation email to subscriber (user)
      await emailjs.send(
        "service_u7g3c4w", // ✅ Your EmailJS service ID
        "template_d7d8aml", // ✅ Template for USER
        {
          to_email: email,
          user_message: "Thanks for subscribing! We'll send you updates soon.",
        },
        "IKqwHtOifIG2f6kix" // ✅ Your public key
      );

      // 3. Notify admin
      await emailjs.send(
        "service_u7g3c4w",
        "template_tvq1fkr",
        {
          user_email: email,
          admin_message: `A new user subscribed with email: ${email}`,
        },
        "IKqwHtOifIG2f6kix"
      );

      alert("✅ Subscribed and both emails sent!");
      setEmail("");
    } catch (error) {
      console.error("Error:", error);
      alert("❌ Failed to subscribe or send emails.");
    }
  };

  return (
    <footer
      className="bg-light text-dark pt-5 pb-4 mt-5 border-top"
      style={{ backgroundImage: "url('./section-2.jpg')", backgroundSize: "cover" }}
    >
      <div className="container">
        <div className="row">

          {/* Brand & Description */}
          <div className="col-md-3 col-lg-3 col-xl-3 mb-4">
            <img src="./Logomain.png" alt="SpiderMentor" width={150} className="mb-3" />
            <p>
              SpiderMentor is your gateway to learning. Join millions of learners globally and unlock your full potential.
            </p>
            <div className="d-flex gap-3 mt-3">
              <a href="#" className="text-dark"><i className="bi bi-facebook fs-5"></i></a>
              <a href="#" className="text-dark"><i className="bi bi-twitter fs-5"></i></a>
              <a href="#" className="text-dark"><i className="bi bi-instagram fs-5"></i></a>
              <a href="#" className="text-dark"><i className="bi bi-linkedin fs-5"></i></a>
            </div>
          </div>

          {/* About SpiderMentor */}
          <div className="col-md-2 col-lg-2 col-xl-2 mb-4">
            <h6 className="text-uppercase fw-bold mb-4">About SpiderMentor</h6>
            <p><a href="/about" className="text-reset text-decoration-none">About Us</a></p>
            <p><a href="/register-instructor" className="text-reset text-decoration-none">Instructor Registration</a></p>
            <p><a href="/become-teacher" className="text-reset text-decoration-none">Become a Teacher</a></p>
            <p><a href="/instructors" className="text-reset text-decoration-none">All Instructors</a></p>
            <p><a href="/faq" className="text-reset text-decoration-none">Asked Question</a></p>
            <p><a href="/contact" className="text-reset text-decoration-none">Contact Us</a></p>
          </div>

          {/* Popular Courses */}
          <div className="col-md-3 col-lg-3 col-xl-3 mb-4">
            <h6 className="text-uppercase fw-bold mb-4">Popular Courses</h6>
            <p><a href="/courses/development" className="text-reset text-decoration-none">Development</a></p>
            <p><a href="/courses/design" className="text-reset text-decoration-none">Arts & Design</a></p>
            <p><a href="/courses/visual" className="text-reset text-decoration-none">Visual Design</a></p>
            <p><a href="/courses/graphic" className="text-reset text-decoration-none">Graphic Design</a></p>
            <p><a href="/courses/code" className="text-reset text-decoration-none">Code Inspection</a></p>
            <p><a href="/courses/marketing" className="text-reset text-decoration-none">Digital Marketing</a></p>
          </div>

          {/* Contact Info */}
          <div className="col-md-4 col-lg-4 col-xl-4 mb-4">
            <h6 className="text-uppercase fw-bold mb-4">Contact Info</h6>
            <p><i className="bi bi-geo-alt me-2"></i> Sector 15, Noida, India</p>
            <p><i className="bi bi-telephone me-2"></i> +91 98765 43210</p>
            <p><i className="bi bi-whatsapp me-2"></i> <a href="https://wa.me/919876543210" className="text-decoration-none">Contact WhatsApp</a></p>
            <p><i className="bi bi-envelope me-2"></i> support@spidermentor.com</p>
          </div>
        </div>

        {/* 📧 Newsletter Subscription */}
        <div className="row my-4">
          <div className="col text-center">
            <h6 className="text-uppercase fw-bold mb-3">Stay Updated!</h6>
            <p className="mb-3">Subscribe to our newsletter for latest updates and offers.</p>

            <form
              className="d-flex justify-content-center align-items-center flex-wrap gap-2 mt-3"
              onSubmit={(e) => {
                e.preventDefault();
                handleSubscribe();
              }}
            >
              <input
                type="email"
                className="form-control"
                placeholder="Enter your email"
                style={{
                  maxWidth: "300px",
                  height: "45px",
                  borderRadius: "6px",
                  padding: "10px 15px",
                  border: "1px solid #ccc",
                }}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button
                type="submit"
                className="btn btn-primary"
                style={{ height: "45px", padding: "0 25px", borderRadius: "6px" }}
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        {/* App Download */}
        <div className="row">
          <div className="col text-center">
            <h6 className="text-uppercase fw-bold mb-3">Download App</h6>
            <p>Download our app from app store and Google Play Store.</p>
            <div className="d-flex justify-content-center gap-3">
              <a href="#"><img src="https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg" alt="Google Play" width="150" /></a>
              <a href="#"><img src="https://developer.apple.com/assets/elements/badges/download-on-the-app-store.svg" alt="App Store" width="140" /></a>
            </div>
          </div>
        </div>
      </div>

      {/* Copyright */}
      <div className="text-center py-3 border-top mt-4" style={{ fontSize: "14px" }}>
        © {new Date().getFullYear()} SpiderMentor. All Rights Reserved.
      </div>
    </footer>
  );
};
