import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { authFunction } from "../../Redux/login/action";
import { Navigate, Link } from "react-router-dom";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import { ColorButton } from "../ProdCard/popperprodcard"; // Or replace with a normal <button>

const Login = () => {
  const [userdata, setUser] = useState({ email: "", password: "" });
  const { user, loading, error } = useSelector((store) => store.auth);
  const dispatch = useDispatch();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...userdata, [name]: value });
  };

  const handleLogin = () => {
    const URL = "http://localhost:3000/users"; // JSON Server
    dispatch(authFunction(userdata, URL));
  };

  // Redirect after login
  if (user?.token) {
    return <Navigate to="/" />;
  }

  return (
    <div
      className="container d-flex align-items-center justify-content-center"
      style={{ minHeight: "110vh" }}
    >
      <div
        className="card shadow p-4"
        style={{ maxWidth: "400px", width: "100%" }}
      >
        <h4 className="text-center mb-3">Log In to SpiderMentor</h4>
        <hr />

        {error && <Alert severity="error">{error}</Alert>}

        <input
          type="email"
          name="email"
          className="form-control mb-2"
          placeholder="Email"
          onChange={handleChange}
          value={userdata.email}
        />
        <input
          type="password"
          name="password"
          className="form-control mb-3"
          placeholder="Password"
          onChange={handleChange}
          value={userdata.password}
        />

        <div className="d-grid">
          <ColorButton onClick={handleLogin}>
            {loading ? (
              <CircularProgress size={24} style={{ color: "white" }} />
            ) : (
              "Log in"
            )}
          </ColorButton>
        </div>

        <hr />
        <div className="text-center">
          Don’t have an account? <Link to="/join/signup-popup">Sign up</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
