import React, { useState, useEffect } from "react";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import { ColorButton } from "../ProdCard/popperprodcard"; // Or use a regular button
import { Link, useNavigate } from "react-router-dom";
import "./signup.css";

const Signup = () => {
  const [userdata, setUser] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...userdata, [name]: value });
  };

  const handleSignup = () => {
    setLoading(true);
    setError("");

    const URL = "http://localhost:3000/users"; // 👈 Your JSON Server on port 3000

    // Check if email already exists
    fetch(`${URL}?email=${userdata.email}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.length > 0) {
          setLoading(false);
          setError("User already exists");
        } else {
          // Create new user
          return fetch(URL, {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify(userdata)
          });
        }
      })
      .then((res) => {
        if (!res) return;
        if (!res.ok) throw new Error("Signup failed");
        return res.json();
      })
      .then(() => {
        setLoading(false);
        setSuccess(true);
      })
      .catch(() => {
        setLoading(false);
        setError("Something went wrong");
      });
  };

  useEffect(() => {
    if (success) {
      navigate("/join/login-popup"); // Change route after signup
    }
  }, [success, navigate]);

  return (
    <div
      className="container d-flex justify-content-center align-items-center"
      style={{ minHeight: "110vh" }}
    >
      <div
        className="card p-4 shadow-lg"
        style={{ maxWidth: "400px", width: "100%" }}
      >
        <h4 className="text-center mb-3">Sign up & Start Learning!</h4>
        <hr />
        {error && <Alert severity="error">{error}</Alert>}

        <input
          className="form-control mb-2"
          name="name"
          placeholder="Full Name"
          onChange={handleChange}
          value={userdata.name}
        />
        <input
          className="form-control mb-2"
          name="email"
          type="email"
          placeholder="Email"
          onChange={handleChange}
          value={userdata.email}
        />
        <input
          className="form-control mb-3"
          name="password"
          type="password"
          placeholder="Password"
          onChange={handleChange}
          value={userdata.password}
        />

        <div className="d-grid">
          <ColorButton onClick={handleSignup}>
            {loading ? (
              <CircularProgress size={24} style={{ color: "white" }} />
            ) : (
              "Sign up"
            )}
          </ColorButton>
        </div>

        <hr />
        <div className="text-center">
          Already have an account? <Link to="/join/login-popup">Log in</Link>
        </div>
      </div>
    </div>
  );
};

export default Signup;
